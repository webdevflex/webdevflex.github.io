var mapTitle = document.getElementsByClassName('map_adres'),
    mapText = document.getElementsByClassName('mapAdresText');

for(var i = 0; i < mapTitle.length; i++){
  mapTitle[i].addEventListener('click',function(){
    if(!(this.classList.contains('active'))){
      for(var i = 0; i < mapTitle.length; i++){
        mapTitle[i].classList.remove('active');
      }
      this.classList.add('active');
    }
  })
}

// arrow.onclick = function(){
//   this.classList.toggle('rotate')
// }