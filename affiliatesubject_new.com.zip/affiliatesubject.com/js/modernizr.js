Modernizr.on('webp', function (result) {
    if (result) {
      // supported
    } else {
      // not-supported
    }
  });